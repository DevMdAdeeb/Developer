<?php
session_start();
require_once '../db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id'])) {
    header("Location: ../../index.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$stmt_check = mysqli_prepare($conn, "SELECT is_admin FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt_check, "i", $user_id);
mysqli_stmt_execute($stmt_check);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_check));
mysqli_stmt_close($stmt_check);
if (!$user || $user['is_admin'] != 1) {
    header("Location: ../../logout.php");
    exit();
}

// التحقق من وجود البيانات الأساسية
if (!isset($_POST['property_id']) || !isset($_POST['action'])) {
    header("Location: manage_properties.php");
    exit();
}

$property_id = (int)$_POST['property_id'];
$action = $_POST['action'];

// --- معالجة إجراء التحديث ---
if ($action === 'update') {
    // استقبال البيانات من نموذج التعديل
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $price = filter_var($_POST['price'], FILTER_VALIDATE_FLOAT);
    $contact_phone = trim($_POST['contact_phone']);

    // التحقق من صحة البيانات
    if (empty($title) || empty($description) || $price === false || empty($contact_phone)) {
        header("Location: edit_property.php?id=$property_id&error=empty_fields");
        exit();
    }

    $query = "UPDATE properties SET title = ?, description = ?, price = ?, contact_phone = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssdsi", $title, $description, $price, $contact_phone, $property_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success_message'] = "تم تحديث بيانات العقار بنجاح.";
    } else {
      
    }
    mysqli_stmt_close($stmt);
} 
// --- معالجة إجراء الحذف ---
elseif ($action === 'delete') {
 
    $img_stmt = mysqli_prepare($conn, "SELECT image_path FROM property_images WHERE property_id = ?");
    mysqli_stmt_bind_param($img_stmt, "i", $property_id);
    mysqli_stmt_execute($img_stmt);
    $images_result = mysqli_stmt_get_result($img_stmt);
    while($row = mysqli_fetch_assoc($images_result)) {
        if (file_exists('../../uploads' . $row['image_path'])) {
            unlink('../../uploads' . $row['image_path']);
        }
    }
    mysqli_stmt_close($img_stmt);

    $delete_img_stmt = mysqli_prepare($conn, "DELETE FROM property_images WHERE property_id = ?");
    mysqli_stmt_bind_param($delete_img_stmt, "i", $property_id);
    mysqli_stmt_execute($delete_img_stmt);
    mysqli_stmt_close($delete_img_stmt);

    // حذف العقار نفسه من جدول properties
    $prop_stmt = mysqli_prepare($conn, "SELECT image FROM properties WHERE id = ?");
    mysqli_stmt_bind_param($prop_stmt, "i", $property_id);
    mysqli_stmt_execute($prop_stmt);
    $prop_result = mysqli_stmt_get_result($prop_stmt);
    if($prop_row = mysqli_fetch_assoc($prop_result)) {
         if (file_exists('../../uploads' . $prop_row['image'])) {
            unlink('../../uploads' . $prop_row['image']);
        }
    }
     mysqli_stmt_close($prop_stmt);


    $stmt = mysqli_prepare($conn, "DELETE FROM properties WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $property_id);

    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['success_message'] = "تم حذف العقار وجميع الصور المرتبطة به بنجاح.";
    } else {
        
    }
    mysqli_stmt_close($stmt);
}

// إعادة التوجيه إلى صفحة الإدارة الرئيسية
header("Location: manage_properties.php");
exit();