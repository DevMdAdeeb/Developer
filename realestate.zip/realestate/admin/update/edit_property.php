<?php
session_start();
require_once '../db.php';

// التحقق من أن المستخدم مشرف
if (!isset($_SESSION['user_id'])) { header("Location: ../../index.php"); exit(); }
$user_id = $_SESSION['user_id'];
$stmt_check = mysqli_prepare($conn, "SELECT is_admin FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt_check, "i", $user_id);
mysqli_stmt_execute($stmt_check);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt_check));
mysqli_stmt_close($stmt_check);
if (!$user || $user['is_admin'] != 1) { header("Location: ../../home.php"); exit(); }

// التحقق من وجود ID العقار في الرابط
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage_properties.php");
    exit();
}
$property_id = (int)$_GET['id'];

// جلب بيانات العقار المحدد من قاعدة البيانات
$stmt = mysqli_prepare($conn, "SELECT * FROM properties WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $property_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$property = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// إذا لم يتم العثور على العقار، أعده لصفحة الإدارة
if (!$property) {
    header("Location: manage_properties.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل العقار</title>
    <style>
        .container { 
            max-width: 800px; 
            margin: 40px auto; 
            padding: 20px; 
            background: #fff; 
            border-radius: 8px; 
            box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        .form-group label { 
            display: block; 
            margin-bottom: 5px; 
            font-weight: bold; }
        .form-group input, .form-group textarea { 
            width: 100%; 
            padding: 10px; 
            border: 1px solid #ccc; 
            border-radius: 4px; }
        .form-group button { 
            width: 100%; 
            padding: 12px; 
            background-color: #0055aa; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            font-size: 16px; 
            cursor: pointer; }
    </style>
</head>
<body>
<div class="container">
    <h2>تعديل بيانات العقار: "<?php echo htmlspecialchars($property['title']); ?>"</h2>
    <hr>
    <form action="update_property.php" method="POST">
        <!-- حقل مخفي لتمرير ID العقار والإجراء -->
        <input type="hidden" name="property_id" value="<?php echo $property['id']; ?>">
        <input type="hidden" name="action" value="update">

        <div class="form-group">
            <label for="title">عنوان الإعلان:</label>
            <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($property['title']); ?>" required>
        </div>

        <div class="form-group">
            <label for="description">وصف العقار:</label>
            <textarea id="description" name="description" rows="5" required><?php echo htmlspecialchars($property['description']); ?></textarea>
        </div>

        <div class="form-group">
            <label for="price">السعر:</label>
            <input type="number" id="price" name="price" value="<?php echo htmlspecialchars($property['price']); ?>" step="1" required>
        </div>

        <div class="form-group">
            <label for="contact_phone">رقم التواصل:</label>
            <input type="tel" id="contact_phone" name="contact_phone" value="<?php echo htmlspecialchars($property['contact_phone']); ?>" required>
        </div>
        
        <div class="form-group">
            <button type="submit">حفظ التعديلات</button>
        </div>
    </form>
</div>
</body>
</html>