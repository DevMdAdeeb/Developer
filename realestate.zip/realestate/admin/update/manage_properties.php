<?php
session_start();
require_once '../db.php';

// التحقق من أن المستخدم مشرف 
if (!isset($_SESSION['user_id'])) { header("Location: ../../index.php"); exit(); }
$user_id = $_SESSION['user_id'];
$stmt = mysqli_prepare($conn, "SELECT is_admin FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
mysqli_stmt_close($stmt);
$is_admin = ($user && $user['is_admin'] == 1);
if (!$is_admin) { header("Location: ../../home.php"); exit(); }

// جلب جميع العقارات الموافق عليها (approved = 1)
$query = "SELECT p.*, u.full_name FROM properties p JOIN users u ON p.user_id = u.id WHERE p.approved = 1 ORDER BY p.created_at DESC";
$result = mysqli_query($conn, $query);
if ($result === false) { die("خطأ في استعلام SQL: " . mysqli_error($conn)); }
$approved_properties = [];
while ($row = mysqli_fetch_assoc($result)) {
    $approved_properties[] = $row;
}

// استرداد رسائل الحالة
$success_message = $_SESSION['success_message'] ?? null;
unset($_SESSION['success_message']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة العقارات المنشورة</title>
    <style>
        :root { 
            --primary-color: #0056b3; 
            --success-color: #28a745; 
            --danger-color: #dc3545; 
            --warning-color: #ffc107; 
            --light-bg: #f8f9fa; }
        body { 
            font-family: 'Segoe UI', Tahoma, sans-serif; 
            background: var(--light-bg); 
            margin: 0; padding: 20px; }
        .container { max-width: 1000px; margin: 0 auto; }
        .page-header { text-align: center; margin-bottom: 30px; }
        .page-header h2 { font-size: 28px; }
        .page-header nav a { 
            margin: 0 10px; 
            text-decoration: none; 
            color: var(--primary-color); 
            font-weight: bold; }
        .alert-success { 
            color: #155724; 
            background-color: #d4edda; 
            border: 1px solid #c3e6cb; 
            padding: 15px; 
            border-radius: 5px; 
            margin-bottom: 20px; 
            text-align: center; }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            background: white; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.08); }
        th, td { padding: 12px 15px; text-align: right; border-bottom: 1px solid #ddd; }
        th { background-color: var(--primary-color); color: white; }
        td img { width: 80px; height: 50px; object-fit: cover; border-radius: 5px; }
        .actions a, .actions button { 
            display: inline-block; 
            padding: 6px 12px; 
            margin: 2px; 
            border-radius: 4px; 
            text-decoration: none; 
            color: white; 
            border: none; 
            cursor: pointer; }
        .edit-btn { background-color: var(--warning-color); }
        .delete-btn { background-color: var(--danger-color); }
        .no-properties { text-align: center; padding: 50px; font-size: 18px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <h2>إدارة العقارات المنشورة</h2>
            <nav>
                <a href="../approve_property.php">مراجعة العقارات الجديدة</a>
                <a href="../../logout.php">تسجيل الخروج</a>
        </nav>
    </dv>

    <?php if ($success_message): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
    <?php endif;?>

    <?php if (empty($approved_properties)): ?>
        <p class="no-properties">لا توجد عقارات منشورة حاليًا.</p>
    <?php else: ?>
    <table>
        <thead>
            <tr>
                <th>الصورة</th>
                <th>العنوان</th>
                <th>المالك</th>
                <th>السعر</th>
                <th>إجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($approved_properties as $property): ?>
                <tr>
                    <td><img src="../../uploads/<?php echo htmlspecialchars($property['image']); ?>" alt="صورةالعقار"></td>
                    <td><?php echo htmlspecialchars($property['title']); ?></td>
                    <td><?php echo htmlspecialchars($property['full_name']); ?></td>
                    <td><?php echo number_format($property['price']); ?> ريال</td>
                    <td class="actions">
                        <a href="edit_property.php?id=<?php echo $property['id']; ?>" class="edit-btn">تعديل</a>
                        <!-- زر الحذف داخل فورم للتأمان -->
                        <form action="update_property.php" method="POST" style="display:inline;"onsubmit="return confirm('هل أنت متأكد من رغبتك في حذف هذا العقار نهائيًا؟');">
                            <input type="hidden" name="property_id" value="<?php echo $property['id']; ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" class="delete-btn">حذف</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</body>
</html>