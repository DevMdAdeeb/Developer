<?php
session_start();
require_once '../db.php'; 

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}
$user_id = $_SESSION['user_id'];

$stmt = mysqli_prepare($conn, "SELECT is_admin FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);
$is_admin = ($user && $user['is_admin'] == 1);

//  جلب العقارات التي تنتظر المراجعة
$properties_to_review = [];
if ($is_admin) {
    $query = "SELECT p.*, u.full_name FROM properties p JOIN users u ON p.user_id = u.id WHERE p.status = 'pending' ORDER BY p.created_at ASC";
    $result = mysqli_query($conn, $query);
    if ($result === false) {
        die("خطأ في استعلام SQL: " . mysqli_error($conn));
    }
    while ($property = mysqli_fetch_assoc($result)) {
        $images_stmt = mysqli_prepare($conn, "SELECT image_path FROM property_images WHERE property_id = ?");
        mysqli_stmt_bind_param($images_stmt, "i", $property['id']);
        mysqli_stmt_execute($images_stmt);
        $images_result = mysqli_stmt_get_result($images_stmt);
        $property['all_images'] = [];
        
        while ($img = mysqli_fetch_assoc($images_result)) {
            $property['all_images'][] = $img['image_path'];
        }
        mysqli_stmt_close($images_stmt);
        if (empty($property['all_images']) && !empty($property['image'])) {
             $property['all_images'][] = $property['image'];
        }
        $properties_to_review[] = $property;
    }
}

// --  استرداد رسالة النجاح من الجلسة ---
$success_message = $_SESSION['success_message'] ?? null;
unset($_SESSION['success_message']);
$error_message = $_SESSION['error_message'] ?? null;
unset($_SESSION['error_message']);

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مراجعة العقارات</title>
    <style>
        :root { 
            --primary-color: #0056b3; 
            --success-color: #28a745; 
            --danger-color: #dc3545; 
            --light-bg: #f8f9fa;
            --white-bg: #ffffff;
            --text-color: #333;
        }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: var(--light-bg); 
            margin: 0; 
            padding: 20px; 
            color: var(--text-color); 
        }
        .container { max-width: 800px; margin: 0 auto; }
        .page-header { text-align: center; margin-bottom: 30px; }
        .page-header h2 { font-size: 28px; }
        .page-header .logout-link { color: var(--danger-color); text-decoration: none; }
        .property-card { 
            background: var(--white-bg); 
            border-radius: 10px; 
            padding: 20px; 
            margin-bottom: 25px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            border-left: 5px solid var(--primary-color);
        }
        .property-card h3 { margin: 0 0 15px; color: var(--primary-color); }
        .property-card p { margin: 8px 0; line-height: 1.6; }
        .image-gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px; margin-top: 15px; margin-bottom: 20px; }
        .image-gallery img {
            width: 100%; 
            height: 100px; 
            object-fit: cover; 
            border-radius: 8px; 
            cursor: pointer; 
            transition: transform 0.2s; 
            border: 1px solid #ddd; }
        .image-gallery img:hover { transform: scale(1.05); }
        .actions-form { margin-top: 20px; display: flex; gap: 10px; align-items: center; }
        .actions-form button { color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; transition: opacity 0.3s; }
        .actions-form .approve-btn { background-color: var(--success-color); }
        .actions-form .reject-btn { background-color: var(--danger-color); }
        .actions-form button:hover { opacity: 0.85; }
        .no-properties, .alert { text-align: center; font-size: 18px; color: #777; padding: 50px; background: var(--white-bg); border-radius: 10px; margin: 20px 0; }
        .alert-success { color: #155724; background-color: #d4edda; border: 1px solid #c3e6cb; padding: 15px; }
        .alert-error { color: #721c24; background-color: #f8d7da; border: 1px solid #f5c6cb; padding: 15px; }
        .modal-overlay { 
            position: fixed; 
            top: 0; 
            left: 0; 
            width: 100%; 
            height: 100%; 
            background: rgba(0,0,0,0.6); 
            z-index: 2000; 
            display: flex; 
            align-items: center; 
            justify-content: center; }
        .modal-content { background: white; padding: 40px; border-radius: 10px; text-align: center; max-width: 400px; box-shadow: 0 5px 20px rgba(0,0,0,0.3); }
        .modal-content h3 { color: var(--danger-color); font-size: 24px; }
    </style>
</head>
<body>

    <?php if (!$is_admin): ?>
        <!-- نافذة عدم الصلاحية -->
        <div class="modal-overlay">
            <div class="modal-content">
                <h3>وصول مرفوض</h3>
                <p>ليس لديك الصلاحية اللازمة للوصول إلى هذه الصفحة.</p>
                <p>سيتم إعادة توجيهك الآن...</p>
            </div>
        </div>
        <script>
            setTimeout(function() { window.location.href = '../home.php'; }, 3000);
        </script>
    <?php else: ?>
        <!-- محتوى الصفحة للمشرف -->
        <div class="container">
            <div class="page-header">
                <h2>لوحة تحكم المشرف</h2>
                <p>العقارات في انتظار المراجعة. <a href="../logout.php" class="logout-link">تسجيل الخروج</a></p>
            </div>
            
            <!-- عرض رسائل الحالة -->
            <?php if ($success_message): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
            <?php endif; ?>
            <?php if ($error_message): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <!-- عرض العقارات -->
            <?php if (empty($properties_to_review)): ?>
                <div class="no-properties"> لا توجد عقارات جديدة تحتاج إلى مراجعة حاليًا.</div>
            <?php else: ?>
                <?php foreach ($properties_to_review as $property): ?>
                    <div class="property-card" id="property-<?php echo $property['id']; ?>">
                        <h3><?php echo htmlspecialchars($property['title']); ?></h3>
                        <p><strong>بواسطة:</strong> <?php echo htmlspecialchars($property['full_name']); ?></p>
                        <p><strong>الوصف:</strong> <?php echo nl2br(htmlspecialchars($property['description'])); ?></p>
                        <p><strong>السعر:</strong> <?php echo number_format($property['price']); ?> ريال</p>
                        <p><strong>للتواصل مع المالك:</strong> <?php echo htmlspecialchars($property['contact_phone']); ?></p>
                        
                        <?php if (!empty($property['all_images'])): ?>
                            <div class="image-gallery">
                                <?php foreach ($property['all_images'] as $img_path): ?>
                                    <img src="../<?php echo htmlspecialchars($img_path); ?>" alt="صورة عقار">
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p><em>لم يتم رفع صور لهذا العقار.</em></p>
                        <?php endif; ?>

                        <form action="save_property_review.php" method="POST" class="actions-form">
                            <input type="hidden" name="property_id" value="<?php echo $property['id']; ?>">
                            <button type="submit" name="action" value="approve" class="approve-btn">موافقة</button>
                            <button type="submit" name="action" value="reject" class="reject-btn">رفض</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
    
</body>
</html>