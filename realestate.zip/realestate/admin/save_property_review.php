<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['user_id']) || !isset($_POST['property_id']) || !isset($_POST['action'])) {
    header("Location: approve_property.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt_check = mysqli_prepare($conn, "SELECT is_admin FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt_check, "i", $user_id);
mysqli_stmt_execute($stmt_check);
$result_check = mysqli_stmt_get_result($stmt_check);
$user = mysqli_fetch_assoc($result_check);
mysqli_stmt_close($stmt_check);

if (!$user || $user['is_admin'] != 1) {
    header("Location: ../logout.php");
    exit();
}

$property_id = (int)$_POST['property_id'];
$action = $_POST['action']; 

$new_status = null;
$approved_value = 0;

if ($action === 'approve') {
    $new_status = 'approved';
    $approved_value = 1;
    $_SESSION['success_message'] = "تمت الموافقة على العقار بنجاح.";
} elseif ($action === 'reject') {
    $new_status = 'rejected';
    $approved_value = 0; // تبقى 0
    $_SESSION['success_message'] = "تم رفض العقار بنجاح.";
}

// إذا كان الإجراء غير معروف، لا تكمل
if ($new_status === null) {
    header("Location: approve_property.php");
    exit();
}

$query = "UPDATE properties SET status = ?, approved = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);

if ($stmt) {
    mysqli_stmt_bind_param($stmt, "siii", $new_status, $approved_value, $user_id, $property_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        $_SESSION['error_message'] = "حدث خطأ في قاعدة البيانات أثناء تحديث العقار.";
    }
    
    mysqli_stmt_close($stmt);
} else {
    $_SESSION['error_message'] = "حدث خطأ في تحضير استعلام قاعدة البيانات.";
}

header("Location: approve_property.php");
exit();