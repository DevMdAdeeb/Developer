<?php
$conn = mysqli_connect('localhost', 'root', '', 'real_estate_db');
mysqli_set_charset($conn, "utf8mb4");
?>