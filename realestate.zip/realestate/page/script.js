function toggleMenu() {
  const nav = document.getElementById("navLinks");
  const menuIcon = document.getElementById("menuIcon");
  const closeIcon = document.getElementById("closeIcon");
  const overlay = document.getElementById("overlay");

  nav.classList.toggle("active");
  menuIcon.classList.toggle("hide");
  closeIcon.classList.toggle("show");
  overlay.classList.toggle("show");
}






function openModal() {
    document.getElementById("loginModal").style.display = "flex";
  }

  function closeModal() {
    document.getElementById("loginModal").style.display = "none";
  }

  // إغلاق النافذة عند الضغط خارجها
  window.onclick = function(event) {
    const modal = document.getElementById("loginModal");
    if (event.target === modal) {
      modal.style.display = "none";
    }
  }
  
  


  function openRegisterModal() {
    document.getElementById("registerModal").style.display = "flex";
  }

  function closeRegisterModal() {
    document.getElementById("registerModal").style.display = "none";
  }

  // إغلاق عند الضغط خارج النافذة
  window.onclick = function(event) {
    const loginModal = document.getElementById("loginModal");
    const registerModal = document.getElementById("registerModal");
    if (event.target === loginModal) loginModal.style.display = "none";
    if (event.target === registerModal) registerModal.style.display = "none";
  }
  
  
