<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

// إذا كان لديه دور، لا داعي لعرض هذه الصفحة له مرة أخرى.
$user_id = $_SESSION['user_id'];
$stmt = mysqli_prepare($conn, "SELECT user_type FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!empty($user['user_type'])) {
    if ($user['user_type'] === "زائر") {
        header("Location: ../home.php");
    } else {
        header("Location: ../properties/property_upload.php");
    }
    exit();
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>عقارات تعز</title>
  <link rel="stylesheet" href="style.css"> 
</head>
<body>

<div class="role-container">
    <form action="save_role.php" method="POST">
        <h2>أكمل تسجيلك!</h2>
        <p>اختر نوع الحساب الذي يناسبك للمتابعة.</p>
        <hr style="margin: 20px 0;">

        <label>
            <input type="radio" name="user_type" value="زائر" required> 
            أنا زائر (أريد تصفح العقارات)
        </label>
        <br><br>
        <label>
            <input type="radio" name="user_type" value="صاحب عقار" required> 
            أنا صاحب عقار (أريد عرض عقاراتي)
        </label>
        <br><br>
        <button type="submit">متابعة</button>
    </form>
</div>
</body>
</html>