<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.php");
    exit();
}

// التحقق من صحة البيانات المُرسلة
$user_type = $_POST['user_type'] ?? null; // استقبل نوع المستخدم
$allowed_types = ["زائر", "صاحب عقار"];

if (!$user_type || !in_array($user_type, $allowed_types)) {
    header("Location: select_role.php");
    exit();
}

// تحديث قاعدة البيانات
$user_id = $_SESSION['user_id'];

$query = "UPDATE users SET user_type = ? WHERE id = ?";
$stmt = mysqli_prepare($conn, $query);

// التحقق من نجاح الـ prepare
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "si", $user_type, $user_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    if ($user_type === "زائر") {
        header("Location: ../home.php"); 
    } else {
        header("Location: ../properties/property_upload.php");
    }
    exit();

} else {
    header("Location: ../index.php?error=db_error");
    exit();
}