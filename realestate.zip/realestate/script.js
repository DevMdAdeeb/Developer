// --- وظيفة القائمة الجانبية (الهمبرجر) ---
function toggleMenu() {
    const nav = document.getElementById("navLinks");
    const menuIcon = document.getElementById("menuIcon");
    const closeIcon = document.getElementById("closeIcon");
    const overlay = document.getElementById("overlay");

    nav.classList.toggle("active");
    // تبديل أيقونات الفتح والإغلاق
    const isNavActive = nav.classList.contains("active");
    menuIcon.style.display = isNavActive ? 'none' : 'block';
    closeIcon.style.display = isNavActive ? 'block' : 'none';
    overlay.style.display = isNavActive ? 'block' : 'none';
}

// --- وظيفة سلايدر الصور ---
function changeSlide(button, direction) {
    const slider = button.parentElement;
    const images = slider.querySelectorAll('img');
    let activeIndex = -1;
    images.forEach((img, index) => {
        if (img.classList.contains('active')) {
            activeIndex = index;
        }
    });

    images[activeIndex].classList.remove('active');
    let newIndex = (activeIndex + direction + images.length) % images.length;
    images[newIndex].classList.add('active');
}

// --- وظيفة "طلب الآن" ---
function requestProperty(title, phone) {
    // استخدم alert بسيط وسريع بدلاً من modal معقد
    alert(
        `لطلب العقار: "${title}"\n\n` +
        `يرجى التواصل مباشرة مع صاحب العقار على الرقم:\n` +
        `${phone}\n\n` +
        `ملاحظة: "عقارات تعز" هي منصة عرض فقط وغير مسؤولة عن أي اتفاقيات تتم بين الطرفين.`
    );
}