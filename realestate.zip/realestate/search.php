<?php
// login_handler.php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['sublog'])) {

    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $_SESSION['login_error'] = "يرجى ملء حقلي البريد الإلكتروني وكلمة المرور.";
        header('Location: index.php?show_login=true');
        exit();
    }
    
    // جلب بيانات المستخدم
    $stmt = mysqli_prepare($conn, "SELECT id, password, user_type, is_admin FROM users WHERE email = ?");
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($user = mysqli_fetch_assoc($result)) {
        // التحقق من كلمة المرور
        if (password_verify($password, $user['password'])) {
            // كلمة المرور صحيحة، ابدأ الجلسة
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['last_activity'] = time();

            // التعامل مع "تذكرني"  
            if (isset($_POST['remember'])) {
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', time() + (7 * 24 * 60 * 60)); // صلاحية أسبوع
                
                $token_stmt = mysqli_prepare($conn, "INSERT INTO auth_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
                mysqli_stmt_bind_param($token_stmt, "iss", $user['id'], $token, $expires);
                mysqli_stmt_execute($token_stmt);
                
                setcookie("remember_token", $token, time() + (7 * 24 * 60 * 60), "/");
            }
            
            // التوجيه بناءً على حالة المستخدم
            if ($user['is_admin'] == 1) {
                header("Location: admin/approve_property.php");
            } elseif (empty($user['user_type'])) {
                header("Location: role/select_role.php");
            } elseif ($user['user_type'] === "زائر") {
                header("Location: home.php");
            } else {
                header("Location: properties/property_upload.php");
            }
            exit();

        } else {
            // كلمة المرور غير صحيحة
            $_SESSION['login_error'] = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
            header('Location: index.php?show_login=true');
            exit();
        }
    } else {
        // البريد الإلكتروني غير موجود
        $_SESSION['login_error'] = "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
        header('Location: index.php?show_login=true');
        exit();
    }
    mysqli_stmt_close($stmt);

} else {
    header('Location: index.php');
    exit();
}

mysqli_close($conn);
?>