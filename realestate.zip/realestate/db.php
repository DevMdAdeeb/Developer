<?php

// الاتصال بقاعدة البيانات
$conn = mysqli_connect('localhost', 'root', '', 'real_estate_db');
if (!$conn) {
    die("فشل الاتصال بقاعدة البيانات: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

// بدء الجلسة في مكان واحد فقط
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>