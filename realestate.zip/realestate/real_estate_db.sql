-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 03 يوليو 2025 الساعة 08:01
-- إصدار الخادم: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `real_estate_db`
--

-- --------------------------------------------------------

--
-- بنية الجدول `auth_tokens`
--

CREATE TABLE `auth_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `auth_tokens`
--

INSERT INTO `auth_tokens` (`id`, `user_id`, `token`, `expires_at`) VALUES
(3, 34, '2db88f6b52e44fc83c624b33bbb601ca71aba4847aa740a84c2f07e2f200c76d', '2025-06-26 16:37:23'),
(9, 37, '2b894ce482de0a16dbd07a3dfdb37d204afbcdb912ed9a7635924de12469cfe0', '2025-06-30 23:14:11'),
(11, 40, 'bcbc967ad3877a8104572231f07f068b24b14432b9c4ec2472ba528c3e8e84a1', '2025-07-01 20:05:18'),
(12, 41, '415537bd8a7c57a8e090b6058962045f063c92378cde4e4c5d0aa969d55d12ae', '2025-07-01 20:16:59'),
(17, 43, '80b33520a0cc9b8e2e347beeea00abe20ff5f9c95c53daee73a06d1511ba5f4d', '2025-07-07 09:55:34');

-- --------------------------------------------------------

--
-- بنية الجدول `properties`
--

CREATE TABLE `properties` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `contact_phone` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `approved` tinyint(4) DEFAULT 0,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp(),
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `properties`
--

INSERT INTO `properties` (`id`, `user_id`, `title`, `description`, `price`, `contact_phone`, `image`, `approved`, `status`, `created_at`, `reviewed_by`, `reviewed_at`) VALUES
(2, 42, 'شقة..', 'للايجار, تقع في شارع جمال ، جولة المسبح.', 200000.00, '713473973', 'uploads/prop_685d63eaafda63.85005216.jpg', 1, 'approved', '2025-06-26 18:14:50', 41, '2025-06-26 18:26:18'),
(3, 42, 'فلة', 'فلة للبيع كبيرة تطل على شارع رئيسي، لها حوش كبير و حديقة.', 99999999.99, '713473973', 'uploads/prop_685ea1f896ed15.44114712.jpg', 1, 'approved', '2025-06-27 16:51:52', 42, '2025-06-27 17:04:35'),
(4, 42, 'بيت...', '5 دور 4 شقق بين كل شقة 4 غرف مجلس غرفة نوم غرفة اطفال غرفة ضيوف حمام ومطبخ سيراميك جديد', 150000.00, '713887232', 'uploads/prop_685ea7476e1ef9.03191720.jpg', 1, 'approved', '2025-06-27 17:14:31', 42, '2025-06-27 17:14:49'),
(5, 35, 'عمارة', 'عمارة للبيع في شارع جمال', 100000.00, '712345678', 'uploads/prop_68624294084092.37313885.jpg', 1, 'approved', '2025-06-30 10:53:56', 35, '2025-06-30 10:54:34');

-- --------------------------------------------------------

--
-- بنية الجدول `property_images`
--

CREATE TABLE `property_images` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `property_images`
--

INSERT INTO `property_images` (`id`, `property_id`, `image_path`) VALUES
(8, 2, 'uploads/prop_685d63eaafda63.85005216.jpg'),
(9, 2, 'uploads/prop_685d63eaafee78.47329937.jpg'),
(10, 2, 'uploads/prop_685d63eaaffee2.84632645.jpg'),
(11, 2, 'uploads/prop_685d63eab00c70.43901102.jpg'),
(12, 2, 'uploads/prop_685d63eab01a97.90357562.jpg'),
(13, 2, 'uploads/prop_685d63eab02807.56010569.jpg'),
(14, 2, 'uploads/prop_685d63eab034c2.65196514.jpg'),
(15, 2, 'uploads/prop_685d63eab04151.87720305.jpg'),
(16, 3, 'uploads/prop_685ea1f896ed15.44114712.jpg'),
(17, 3, 'uploads/prop_685ea1f89704a3.18955649.jpg'),
(18, 3, 'uploads/prop_685ea1f8971541.82563017.jpg'),
(19, 3, 'uploads/prop_685ea1f8972344.36634676.jpg'),
(20, 4, 'uploads/prop_685ea7476e1ef9.03191720.jpg'),
(21, 4, 'uploads/prop_685ea7476e3510.19081357.jpg'),
(22, 4, 'uploads/prop_685ea7476e4789.23200332.jpg'),
(23, 4, 'uploads/prop_685ea7476e5776.46837220.jpg'),
(24, 4, 'uploads/prop_685ea7476e67a5.04710435.jpg'),
(25, 4, 'uploads/prop_685ea7476e7717.53349210.jpg'),
(26, 5, 'uploads/prop_68624294084092.37313885.jpg'),
(27, 5, 'uploads/prop_686242940872e0.18488011.jpg'),
(28, 5, 'uploads/prop_68624294088585.56498724.jpg'),
(29, 5, 'uploads/prop_686242940896c3.22217246.jpg'),
(30, 5, 'uploads/prop_6862429408a799.55026575.jpg');

-- --------------------------------------------------------

--
-- بنية الجدول `property_reviews`
--

CREATE TABLE `property_reviews` (
  `id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `reviewer_id` int(11) NOT NULL,
  `review_status` enum('مقبول','مرفوض') NOT NULL,
  `review_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `property_reviews`
--

INSERT INTO `property_reviews` (`id`, `property_id`, `reviewer_id`, `review_status`, `review_date`) VALUES
(13, 13, 34, 'مقبول', '2025-06-19 14:43:30'),
(14, 14, 34, 'مقبول', '2025-06-19 15:37:49'),
(15, 16, 34, 'مقبول', '2025-06-19 19:19:46'),
(16, 15, 34, 'مقبول', '2025-06-19 19:19:49'),
(17, 17, 34, 'مقبول', '2025-06-19 19:21:27'),
(18, 18, 34, 'مقبول', '2025-06-19 19:46:17'),
(19, 19, 34, 'مقبول', '2025-06-19 19:59:36'),
(20, 20, 34, 'مقبول', '2025-06-22 20:44:33');

-- --------------------------------------------------------

--
-- بنية الجدول `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` enum('زائر','صاحب عقار') DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- إرجاع أو استيراد بيانات الجدول `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `password`, `user_type`, `is_admin`) VALUES
(35, 'mohammed', 'mosdsdc@gmail.com', '0713887232', '$2y$10$gxFH8Jm5R03605Lft.sEdeATNUxAGQhBojSoOppJAcd6S79Iy1ke6', 'صاحب عقار', 1),
(36, 'ali', 'ms@gamil.com', '0713887232', '$2y$10$zHIxqGCb4M5goRDRLGmPLeJxH/aeN0.2Ljten..gUIHEmwVwBrMma', 'صاحب عقار', 1),
(37, 'محمد اديب', 'medo@gmail.com', '713473973', '$2y$10$oC6xJgZn88CmSRlcpPNN..rouLkE6mUu5vii2pVmReJWks4KjQ8sW', 'زائر', 1),
(38, 'الحسن نائل', 'hassan@gmail.com', '778580466', '$2y$10$5b0nIhkucNIXHarDwLfTWOCd205M/6uRR7UajL9G7KFl0P8lAaS2.', 'زائر', 0),
(39, 'محمد ياسين محمد', 'moh774555@gmail.com', '774606859', '$2y$10$b.WOQdryGqmrnGermJ857ODJaZUd0MIaWcjN5Zb/3Xk5ICkV9tfKy', 'صاحب عقار', 0),
(40, 'كحمد مدهش محمد احمد', 'mmmmbbbb@gmail.com', '776398224', '$2y$10$K0P2tDDg/TvFgIOrA7SP/e2ZaORKRWYzhfH2VC7QDjw/gutw5KhRO', 'زائر', 1),
(41, 'محمد اديب', 'med1o@gmail.com', '713473973', '$2y$10$fryd1dGWqox7jRncmfTx7eJ8MwRzMx2.CzcXlz0BxeDTrdFR6Kuhy', 'زائر', 1),
(42, 'mohammeddsvs', 'mosdwqersdc@gmail.com', '0713887232', '$2y$10$nbgrj.0O8I6QV56AAuUzEOUWQAF1DHZ2LZzIMLLRrg2sThXKIsuIm', 'صاحب عقار', 1),
(43, 'mohammed', 'mosds11dc@gmail.com', '0713887232', '$2y$10$3TrmKNGGL.uVfCkgytUE.OhiXYD3lUKKue7H3VOjIqLF/uEoUZZy.', 'زائر', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_tokens`
--
ALTER TABLE `auth_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `property_images`
--
ALTER TABLE `property_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `property_id` (`property_id`);

--
-- Indexes for table `property_reviews`
--
ALTER TABLE `property_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `property_id` (`property_id`),
  ADD KEY `reviewer_id` (`reviewer_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_tokens`
--
ALTER TABLE `auth_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `property_images`
--
ALTER TABLE `property_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `property_reviews`
--
ALTER TABLE `property_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- قيود الجداول المُلقاة.
--

--
-- قيود الجداول `auth_tokens`
--
ALTER TABLE `auth_tokens`
  ADD CONSTRAINT `auth_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `properties_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `property_images`
--
ALTER TABLE `property_images`
  ADD CONSTRAINT `property_images_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE;

--
-- قيود الجداول `property_reviews`
--
ALTER TABLE `property_reviews`
  ADD CONSTRAINT `property_reviews_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`),
  ADD CONSTRAINT `property_reviews_ibfk_2` FOREIGN KEY (`reviewer_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
