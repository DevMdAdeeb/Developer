<?php
session_start();
require_once '../db.php'; // تأكد من أن المسار يعود للخلف

// --- الخطوة 1: التحقق الصارم من وجود جلسة صالحة ---
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ../index.php?error=session_expired');
    exit();
}
$user_id = $_SESSION['user_id'];

// --- الخطوة 2: التحقق من دور المستخدم كطبقة حماية إضافية ---
$stmt_check = mysqli_prepare($conn, "SELECT user_type FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt_check, "i", $user_id);
mysqli_stmt_execute($stmt_check);
$user_result = mysqli_stmt_get_result($stmt_check);
$user = mysqli_fetch_assoc($user_result);
mysqli_stmt_close($stmt_check);

if (!$user || $user['user_type'] !== 'صاحب عقار') {
    header('Location: ../home.php'); // إذا حاول شخص غير مصرح له الوصول، وجهه للخارج
    exit();
}

// --- الخطوة 3: استقبال البيانات من النموذج مع تنظيفها والتحقق منها ---
$title = trim($_POST['title'] ?? '');
$description = trim($_POST['description'] ?? '');
$price = filter_var($_POST['price'] ?? 0, FILTER_VALIDATE_FLOAT);
$contact_phone = trim($_POST['contact_phone'] ?? '');

// التحقق من أن جميع الحقول المطلوبة ليست فارغة
if (empty($title) || empty($description) || $price === false || $price <= 0 || empty($contact_phone)) {
    $_SESSION['error_message'] = "الرجاء ملء جميع الحقول بشكل صحيح والتأكد من أن السعر رقم موجب.";
    header('Location: property_upload.php');
    exit();
}

// --- الخطوة 4: معالجة رفع الصور ---
if (!isset($_FILES['images']) || empty(array_filter($_FILES['images']['name']))) {
    $_SESSION['error_message'] = "يجب رفع صورة واحدة على الأقل.";
    header('Location: property_upload.php');
    exit();
}

$allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
$upload_dir = '../uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true); // إنشاء مجلد uploads إذا لم يكن موجودًا
}
$uploaded_images_paths = [];

foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
    if ($_FILES['images']['error'][$key] !== UPLOAD_ERR_OK) {
        continue; // تخطى الملفات التي بها أخطاء في الرفع
    }
    
    $file_name = $_FILES['images']['name'][$key];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if (!in_array($file_ext, $allowed_extensions)) {
        $_SESSION['error_message'] = "امتداد الصورة '$file_name' غير مسموح به. الامتدادات المسموحة: jpg, jpeg, png, gif.";
        header('Location: property_upload.php');
        exit();
    }

    // إنشاء اسم فريد للصورة لمنع استبدال الملفات
    $new_file_name = uniqid('prop_', true) . '.' . $file_ext;
    $upload_path = $upload_dir . $new_file_name;

    if (move_uploaded_file($tmp_name, $upload_path)) {
        // نخزن المسار كما سيُستخدم في قاعدة البيانات (بدون ../)
        $uploaded_images_paths[] = 'uploads/' . $new_file_name;
    } else {
        $_SESSION['error_message'] = "حدث خطأ فني أثناء محاولة رفع الصور.";
        header('Location: property_upload.php');
        exit();
    }
}

// إذا فشلت جميع عمليات رفع الصور لسبب ما
if (empty($uploaded_images_paths)) {
    $_SESSION['error_message'] = "لم يتم رفع أي صور بنجاح. يرجى المحاولة مرة أخرى.";
    header('Location: property_upload.php');
    exit();
}

// --- الخطوة 5: حفظ بيانات العقار الرئيسية في جدول `properties` ---
$main_image = $uploaded_images_paths[0]; // الصورة الأولى هي الصورة الرئيسية للعقار

$query = "INSERT INTO properties (user_id, title, description, price, contact_phone, image, approved, status)
          VALUES (?, ?, ?, ?, ?, ?, 0, 'pending')";
          
$stmt = mysqli_prepare($conn, $query);

if ($stmt === false) {
    // هذا يعني وجود خطأ في جملة SQL نفسها
    $_SESSION['error_message'] = 'فشل في تحضير استعلام SQL: ' . mysqli_error($conn);
    header('Location: property_upload.php');
    exit();
}

// ربط المتغيرات بالاستعلام
mysqli_stmt_bind_param($stmt, "issdss", $user_id, $title, $description, $price, $contact_phone, $main_image);

// تنفيذ الاستعلام وحفظ العقار
if (mysqli_stmt_execute($stmt)) {
    $property_id = mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);

    // --- الخطوة 6: حفظ مسارات جميع الصور في جدول `property_images` ---
    $img_query = "INSERT INTO property_images (property_id, image_path) VALUES (?, ?)";
    $img_stmt = mysqli_prepare($conn, $img_query);

    if ($img_stmt) {
        foreach ($uploaded_images_paths as $image_path) {
            mysqli_stmt_bind_param($img_stmt, "is", $property_id, $image_path);
            mysqli_stmt_execute($img_stmt);
        }
        mysqli_stmt_close($img_stmt);
    }

    // --- الخطوة 7: إرسال رسالة النجاح وإعادة التوجيه ---
    $_SESSION['success_message'] = "تم رفع عقارك بنجاح! سيتم مراجعته من قبل المشرف في أقرب وقت.";
    header('Location: property_upload.php');
    exit();

} else {
    // إذا فشل التنفيذ، اعرض الخطأ الدقيق من MySQL
    $_SESSION['error_message'] = "حدث خطأ في قاعدة البيانات أثناء حفظ العقار: " . mysqli_stmt_error($stmt);
    header('Location: property_upload.php');
    exit();
}