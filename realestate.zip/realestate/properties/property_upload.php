<?php
session_start();
require_once '../db.php'; 

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('Location: ../index.php?error=session_expired');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = mysqli_prepare($conn, "SELECT user_type FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$user || $user['user_type'] !== 'صاحب عقار') {
    header('Location: ../home.php');
    exit();
}

$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;

unset($_SESSION['success_message'], $_SESSION['error_message']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>إضافة عقار جديد - عقارات تعز</title>
  <!-- <link rel="stylesheet" href="../style.css">  -->
  <style>
    .container { 
        max-width: 800px; 
        margin: 40px auto; 
        padding: 20px; 
        background: #fff; 
        border-radius: 8px; 
        box-shadow: 0 0 10px rgba(0,0,0,0.1);}
    .form-header { text-align: center; margin-bottom: 20px; }
    .form-header h2 { margin-bottom: 10px; }
    .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; text-align: center; }
    .alert-success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
    .alert-error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    .form-group { margin-bottom: 15px; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
    .form-group input, .form-group textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .form-group button {
        width: 100%;
        padding: 12px;
        background-color: #0055aa;
        color: white;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
    .form-group button:hover { background-color: #003366; }
  </style>
</head>
<body>

<div class="container">
    <div class="form-header">
        <h2>إضافة عقار جديد</h2>
        <p>املأ النموذج التالي لرفع عقارك. سيتم مراجعته من قبل المشرف قبل النشر.</p>
    </div>
    <hr style="margin-bottom: 20px;">
    
    <?php if ($success_message): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
    <?php endif; ?>
    <?php if ($error_message): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error_message); ?></div>
    <?php endif; ?>

    <form action="save_property.php" method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label for="title">عنوان الإعلان :</label>
            <input type="text" id="title" name="title" required>
        </div>

        <div class="form-group">
            <label for="description">وصف العقار:</label>
            <textarea id="description" name="description" rows="5" required></textarea>
        </div>

        <div class="form-group">
            <label for="price">السعر (بالريال اليمني):</label>
            <input type="number" id="price" name="price" step="1" required>
        </div>

        <div class="form-group">
            <label for="contact_phone">رقم التواصل:</label>
            <input type="tel" id="contact_phone" name="contact_phone" pattern="7[0-9]{8}" placeholder="مثال: 777123456" required>
        </div>

        <div class="form-group">
            <label for="images">صور العقار (يمكنك تحديد عدة صور):</label>
            <input type="file" id="images" name="images[]" accept="image/png, image/jpeg, image/gif" required multiple>
        </div>

        <div class="form-group">
            <button type="submit">رفع العقار للمراجعة</button>
            <a href="../home.php"> رجوع الى الصفحة الرئيسية </a>
        </div>
    </form>
</div>

</body>
</html>