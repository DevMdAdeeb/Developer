<?php
session_start();

//  إلغاء تعيين جميع متغيرات الجلسة
$_SESSION = [];

// تدمير الجلسة
session_destroy();

// حذف كوكي "تذكرني" من متصفح المستخدم وقاعدة البيانات
if (isset($_COOKIE['remember_token'])) {
    // الحذف من المتصفح
    setcookie('remember_token', '', time() - 3600, '/');
    
    // الحذف من قاعدة البيانات لزيادة الأمان
    require_once 'db.php';
    $token_to_delete = $_COOKIE['remember_token'];
    $stmt = mysqli_prepare($conn, "DELETE FROM auth_tokens WHERE token = ?");
    mysqli_stmt_bind_param($stmt, "s", $token_to_delete);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}

// إعادة التوجيه إلى صفحة تسجيل الدخول
header('Location: index.php');
exit();
?>