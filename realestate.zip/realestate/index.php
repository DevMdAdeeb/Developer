<?php
session_start();
//require_once 'db.php';

function redirect_user($conn, $user_id) {
    $stmt = mysqli_prepare($conn, "SELECT user_type, is_admin FROM users WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if ($user) {
        if ($user['is_admin'] == 1) {
            header("Location: admin/approve_property.php");
            exit();
        }
        if (empty($user['user_type'])) {
            header("Location: role/select_role.php"); 
            exit();
        }
        if ($user['user_type'] === "زائر") {
            header("Location: home.php");
            exit();
        } else {
            header("Location: properties/property_upload.php");
            exit();
        }
    }
}

// 1. التحقق من وجود جلسة نشطة
if (isset($_SESSION['user_id'])) {
    // $_SESSION['last_activity'] = time();
    redirect_user($conn, $_SESSION['user_id']);
}
//  إذا لا توجد جلسة، تحقق من كوكي "تذكرني" الآمن
if (isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];

    $stmt = mysqli_prepare($conn, "SELECT user_id FROM auth_tokens WHERE token = ? AND expires_at > NOW()");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $user_id);
    
    $found_user = mysqli_stmt_fetch($stmt); 
    mysqli_stmt_close($stmt);
    
    // اذا المستخدم موجود يتم تسجيل دخوله
    if ($found_user) {
        $_SESSION['user_id'] = $user_id;
        $_SESSION['last_activity'] = time();
        redirect_user($conn, $user_id);
    }
}
// استرداد رسائل الخطأ من الجلسة لعرضها
$login_error = $_SESSION['login_error'] ?? null;
$register_errors = $_SESSION['register_errors'] ?? [];
$old_data = $_SESSION['old_data'] ?? [];

// حذف رسائل الخطأ من الجلسة بعد عرضها لمنع ظهورها مرة أخرى
unset($_SESSION['login_error'], $_SESSION['register_errors'], $_SESSION['old_data']);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>عقارات تعز</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <header class="navbar">
     <div class="logo">عقارات تعز</div>
    <nav class="nav-links" id="navLinks">
      <a href="index.php">الرئيسية</a>
      <a href="page/about-us.html">عنّا</a>
      <a href="page/services.html">الخدمات</a>
      <a href="page/contact-us.html">تواصل معنا</a>
    </nav>
    <div class="menu-icon" id="menuIcon" onclick="toggleMenu()">&#9776;</div>
    <div class="close-icon" id="closeIcon" onclick="toggleMenu()">&#10006;</div>
  </header>
  
  <div class="center-wrapper">
    <div class="welcome-message">
        <h2>مرحبًا بك في منصتنا العقارية!</h2>
        <p>اكتشف أفضل العقارات للبيع والإيجار في موقع واحد. ابدأ رحلتك الآن للعثور على بيت أحلامك أو استثمارك المثالي.</p>
    </div>

    <div class="auth-buttons">
        <button onclick="openModal('loginModal')" class="open-login-btn">تسجيل الدخول</button>
        <button onclick="openModal('registerModal')" class="open-register-btn">إنشاء حساب</button>
    </div>
  </div>

<!-- نافذة تسجيل الدخول -->
<div id="loginModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('loginModal')">×</span>
    <h2>تسجيل الدخول</h2>
    <?php if ($login_error): ?>
        <p style="color: red;"><?php echo $login_error; ?></p>
    <?php endif; ?>
    <form action="search.php" method="post">
      <label for="email">البريد الإلكتروني</label>
      <input type="email" name="email" required>
        
      <label for="password">كلمة المرور</label>
      <input type="password" name="password" required>
      
      <button type="submit" name="sublog">دخول</button>
      <label><input type="checkbox" name="remember"> تذكرني</label>
    </form>
  </div>
</div>
   
<!-- نافذة إنشاء حساب -->
<div id="registerModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal('registerModal')">×</span>
    <h2>إنشاء حساب</h2>
    <?php if (!empty($register_errors)): ?>
        <div style="color: red;">
            <ul>
                <?php foreach ($register_errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="save.php" method="post">
      <label for="name">الاسم الكامل</label>
      <input type="text" name="full_name" required value="<?php echo htmlspecialchars($old_data['full_name'] ?? ''); ?>">

      <label for="email">البريد الإلكتروني</label>
      <input type="email" name="email" required value="<?php echo htmlspecialchars($old_data['email'] ?? ''); ?>">
      <label for="phone">رقم الهاتف</label>
      <input type="tel" name="phone" placeholder="7xxxxxxxx" required value="<?php echo htmlspecialchars($old_data['phone'] ?? ''); ?>">
      <label for="password">كلمة المرور (8 أحرف على الأقل)</label>
      <input type="password" name="password" required>
      <label><input type="checkbox" name="remember1"> تذكرني</label>
      <button type="submit" name="submit">إنشاء</button>
    </form>
  </div>
</div>

<script>
// سكربت بسيط لفتح وإغلاق النوافذ
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// فتح النافذة تلقائيا إذا كان هناك خطأ
<?php if (isset($_GET['show_login'])): ?>
    openModal('loginModal');
<?php elseif (isset($_GET['show_register'])): ?>
    openModal('registerModal');
<?php endif; ?>
</script>
</body>
</html>