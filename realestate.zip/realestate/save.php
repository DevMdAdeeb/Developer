<?php
// register_handler.php
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {

    $errors = [];
    
    // 1. استقبال البيانات مع التحقق
    $fullName = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];

    if (empty($fullName)) $errors[] = "الاسم الكامل مطلوب.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "البريد الإلكتروني غير صالح.";
    if (empty($phone)) $errors[] = "رقم الهاتف مطلوب.";
    if (strlen($password) < 8) $errors[] = "كلمة المرور يجب أن لا تقل عن 8 أحرف.";

    // التحقق من وجود البريد مسبقاً (فقط إذا كانت المدخلات الأولية صالحة)
    if (empty($errors)) {
        $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        if (mysqli_stmt_num_rows($stmt) > 0) {
            $errors[] = "هذا البريد الإلكتروني مسجل بالفعل.";
        }
        mysqli_stmt_close($stmt);
    }
    
    //إذا وجد أخطاء، ارجع للصفحة الرئيسية مع الأخطاء
    if (!empty($errors)) {
        $_SESSION['register_errors'] = $errors;
        $_SESSION['old_data'] = $_POST; // لإعادة ملء النموذج
        header('Location: index.php?show_register=true'); // نعود مع مؤشر لفتح نافذة التسجيل
        exit();
    }
    
    // إذا كان كل شيء سليماً، قم بإضافة المستخدم
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $safeFullName = htmlspecialchars($fullName);

    $stmt = mysqli_prepare($conn, "INSERT INTO users (full_name, email, phone, password) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "ssss", $safeFullName, $email, $phone, $hashedPassword);
    
    if (mysqli_stmt_execute($stmt)) {
        $new_user_id = mysqli_insert_id($conn);
        
        // تسجيل الدخول مباشرة
        $_SESSION['user_id'] = $new_user_id;
        $_SESSION['last_activity'] = time();

        // التعامل مع "تذكرني" 
        if (isset($_POST['remember1'])) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + (7 * 24 * 60 * 60));
            
            $token_stmt = mysqli_prepare($conn, "INSERT INTO auth_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($token_stmt, "iss", $new_user_id, $token, $expires);
            mysqli_stmt_execute($token_stmt);
            
            setcookie("remember_token", $token, time() + (7 * 24 * 60 * 60), "/");
        }
        
        // بما أن المستخدم جديد، نوجهه دائماً لصفحة اختيار الدور
        header('Location: role/select_role.php');
        exit();

    } else {
        $_SESSION['register_errors'] = ["حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى."];
        header('Location: index.php?show_register=true');
        exit();
    }
    mysqli_stmt_close($stmt);
} else {
    // إذا تم الوصول للملف مباشرة
    header('Location: index.php');
    exit();
}

mysqli_close($conn);
?>