<?php
session_start();
require_once 'db.php';

// --- آلية التحقق من تسجيل الدخول الآمنة ---
$user_id = null;
$user_type = null;

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else if (isset($_COOKIE['remember_token'])) {
    $token = $_COOKIE['remember_token'];
    $stmt = mysqli_prepare($conn, "SELECT user_id FROM auth_tokens WHERE token = ? AND expires_at > NOW()");
    mysqli_stmt_bind_param($stmt, "s", $token);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($result)) {
        $_SESSION['user_id'] = $row['user_id'];
        $user_id = $_SESSION['user_id'];
    }
    mysqli_stmt_close($stmt);
}

if ($user_id === null) {
    header('Location: index.php');
    exit();
}

// --- جلب بيانات المستخدم لتحديد نوعه ---
$user_stmt = mysqli_prepare($conn, "SELECT user_type FROM users WHERE id = ?");
mysqli_stmt_bind_param($user_stmt, "i", $user_id);
mysqli_stmt_execute($user_stmt);
$user_result = mysqli_stmt_get_result($user_stmt);
if ($user_data = mysqli_fetch_assoc($user_result)) {
    $user_type = $user_data['user_type'];
}
mysqli_stmt_close($user_stmt);

// --- جلب العقارات المعروضة للجميع (المقبولة فقط) ---
$properties_query = "SELECT p.*, u.full_name FROM properties p JOIN users u ON p.user_id = u.id WHERE p.approved = 1 ORDER BY p.created_at DESC";
$properties_result = mysqli_query($conn, $properties_query);
$all_properties = [];

while ($property = mysqli_fetch_assoc($properties_result)) {
    $images_query = "SELECT image_path FROM property_images WHERE property_id = ?";
    $images_stmt = mysqli_prepare($conn, $images_query);
    mysqli_stmt_bind_param($images_stmt, "i", $property['id']);
    mysqli_stmt_execute($images_stmt);
    $images_result = mysqli_stmt_get_result($images_stmt);
    $property['images'] = [];

    while ($img_row = mysqli_fetch_assoc($images_result)) {
        $property['images'][] = $img_row['image_path'];
    }
    if (empty($property['images'])) {
        $property['images'][] = $property['image']; // أضف الصورة الرئيسية
    }
    mysqli_stmt_close($images_stmt);
    $all_properties[] = $property;
}

// --- [جديد] جلب عقارات المستخدم الحالي (إذا كان صاحب عقار) ---
$my_properties = [];
if ($user_type === 'صاحب عقار') {
    $my_prop_query = "SELECT * FROM properties WHERE user_id = ? ORDER BY created_at DESC";
    $my_prop_stmt = mysqli_prepare($conn, $my_prop_query);
    mysqli_stmt_bind_param($my_prop_stmt, "i", $user_id);
    mysqli_stmt_execute($my_prop_stmt);
    $my_prop_result = mysqli_stmt_get_result($my_prop_stmt);
    while ($prop = mysqli_fetch_assoc($my_prop_result)) {
        $my_properties[] = $prop;
    }
    mysqli_stmt_close($my_prop_stmt);
}

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عقارات تعز - الرئيسية</title>
    <style>
        /* --- جميع تنسيقات CSS هنا --- */
        :root {
            --primary-color: #003366;
            --secondary-color: #0055aa;
            --danger-color: #c0392b;
            --light-bg: #f5f5f5;
        }
        * { 
            box-sizing: border-box; margin: 0; padding: 0; }
        body { 
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background-color: var(--light-bg); }
        .navbar { 
            display: flex;
            align-items: center; 
            justify-content: space-between; 
            background-color: var(--primary-color); 
            padding: 10px 20px; 
            color: white; 
            position: sticky; 
            top: 0; 
            z-index: 1001; }
        .logo {
            font-size: 20px; 
            font-weight: bold; }
        .nav-links { 
            display: flex; 
            gap: 15px; 
            align-items: center; }
        .nav-links a, .nav-links button { 
            color: white; 
            text-decoration: none; 
            padding: 8px 12px; 
            border: none; 
            background: none; 
            font-size: 16px; 
            cursor: pointer; 
            transition: background 0.3s; border-radius: 4px; }
        .nav-links a:hover, .nav-links button:hover { background-color: var(--secondary-color); }
        .nav-links .logout-btn { background-color: var(--danger-color); }
        .menu-icon, .close-icon { display: none; font-size: 24px; cursor: pointer; }
        .overlay {
            position: fixed; 
            top: 0; 
            right: 0; 
            bottom: 0; 
            left: 0; 
            background: rgba(0,0,0,0.5); 
            display: none; 
            z-index: 1000; }
        .page-container { 
            max-width: 1200px; 
            margin: 20px auto; 
            padding: 0 15px; }
        .section-title { 
            font-size: 24px; 
            color: var(--primary-color); 
            border-bottom: 2px solid var(--primary-color); 
            padding-bottom: 10px; 
            margin-bottom: 20px; }
        .properties-grid { 
            display: grid; 
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); 
            gap: 20px; }
        .card { 
            background: white; 
            border-radius: 8px; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
            overflow: hidden; 
            display: flex; 
            flex-direction: column; }
        .image-slider { 
            position: relative; 
            width: 100%; 
            height: 200px; 
            background-color: #eee; }
        .image-slider img { 
            width: 100%; 
            height: 100%; 
            object-fit: cover; 
            position: absolute; 
            top: 0; 
            left: 0; 
            opacity: 0; 
            transition: opacity 0.4s ease; 
            z-index: 1; }
        .image-slider img.active { opacity: 1; z-index: 2; }
        .slider-btn { 
            position: absolute; 
            top: 50%; 
            transform: translateY(-50%); 
            background: rgba(0,0,0,0.4); 
            color: white; 
            border: none; 
            padding: 5px 10px; 
            cursor: pointer; 
            font-size: 20px; 
            z-index: 3; 
            border-radius: 50%; 
            width: 35px; 
            height: 35px; 
            display: flex; 
            align-items: center; 
            justify-content: center; }
        .slider-btn.prev { left: 10px; }
        .slider-btn.next { right: 10px; }
        .details { padding: 15px; flex-grow: 1; display: flex; flex-direction: column; }
        .details h3 { font-size: 18px; margin-bottom: 10px; }
        .details p { font-size: 14px; color: #555; margin-bottom: 8px; line-height: 1.5; }
        .details strong { color: #333; }
        .request-btn { 
            background-color: var(--secondary-color); 
            color: white; 
            border: none; 
            padding: 12px; 
            border-radius: 5px; 
            font-size: 16px; 
            width: 100%; 
            margin-top: auto; 
            cursor: pointer; }
        .status-badge { 
            padding: 5px 10px; 
            border-radius: 15px; 
            color: white; 
            font-size: 12px; 
            display: inline-block; }
        .status-pending { background-color: #f39c12; }
        .status-approved { background-color: #2ecc71; }
        .status-rejected { background-color: #e74c3c; }

        @media (max-width: 768px) {
            .nav-links { 
                position: fixed; 
                top: 0; 
                right: -280px; 
                width: 250px; 
                height: 100%; 
                background-color: var(--primary-color); 
                flex-direction: column; 
                padding-top: 60px; 
                transition: right 0.4s ease-in-out; 
                z-index: 1002; 
                align-items: flex-start; 
                padding-right: 20px; }
            .nav-links.active { right: 0; }
            .menu-icon, .close-icon { display: block; z-index: 1003; }
            .close-icon { display: none; }
            .overlay.show { display: block; }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <div class="logo">عقارات تعز</div>
        <nav class="nav-links" id="navLinks">
            <?php if ($user_type === 'صاحب عقار'): ?>
                <a href="properties/property_upload.php">إضافة عقار</a>
                <?php endif; ?>
            <a href="home.php">الرئيسية</a>
            <a href="page/about-us.html">عنّا</a>
            <a href="page/services.html">الخدمات</a>
            <a href="page/contact-us.html">تواصل معنا</a>
            <form action="logout.php" method="post" style="margin: 0;">
                <button type="submit" class="logout-btn">تسجيل الخروج</button>
            </form>
        </nav>
        <div class="menu-icon" id="menuIcon" onclick="toggleMenu()">☰</div>
        <div class="close-icon" id="closeIcon" onclick="toggleMenu()">✖</div>
    </header>
    <div class="overlay" id="overlay" onclick="toggleMenu()"></div>

    <div class="page-container">

        <!-- [جديد] قسم عقاراتي (يظهر لصاحب العقار فقط) -->
        <?php if ($user_type === 'صاحب عقار' && !empty($my_properties)): ?>
<section id="my-properties">
    <h2 class="section-title">عقاراتي</h2>
    <div class="properties-grid">
        <?php foreach ($my_properties as $prop): ?>
            <div class="card">
                <div class="image-slider">
                    <img src="<?php echo htmlspecialchars($prop['image']); ?>" class="active" alt="صورة العقار">
                </div>
                <div class="details">
                    <h3><?php echo htmlspecialchars($prop['title']); ?></h3>
                    <p><strong>الحالة:</strong> 
                        <?php
                            $status_text = 'قيد المراجعة';
                            $status_class = 'status-pending';
                            if ($prop['status'] === 'approved') {
                                $status_text = 'مقبول ومنشور';
                                $status_class = 'status-approved';
                            } elseif ($prop['status'] === 'rejected') {
                                $status_text = 'مرفوض';
                                $status_class = 'status-rejected';
                            }
                        ?>
                        <span class="status-badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                    </p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
            </section>
            <hr style="margin: 40px 0; border: 1px solid #ddd;">
        <?php endif; ?>

        <!-- قسم العقارات المتاحة للجميع -->
        <section id="all-properties">
            <h2 class="section-title">أحدث العقارات</h2>
            <div class="properties-grid">
                <?php if (empty($all_properties)): ?>
                    <p>لا توجد عقارات متاحة للعرض حاليًا.</p>
                <?php else: ?>
                    <?php foreach ($all_properties as $property): ?>
                        <div class="card">
                            <div class="image-slider">
                                <?php foreach ($property['images'] as $index => $image_path): ?>
                                    <img src="<?php echo htmlspecialchars($image_path); ?>" 
                                         alt="صورة لـ <?php echo htmlspecialchars($property['title']); ?>" 
                                         class="<?php echo ($index === 0) ? 'active' : ''; ?>">
                                <?php endforeach; ?>
                                <?php if (count($property['images']) > 1): ?>
                                    <button class="slider-btn prev" onclick="changeSlide(this, -1)">❯</button>
                                    <button class="slider-btn next" onclick="changeSlide(this, 1)">❮</button>
                                <?php endif; ?>
                            </div>
                            <div class="details">
                              <h3><?php echo htmlspecialchars($property['title']); ?></h3>
                               
                                <p><?php echo nl2br(htmlspecialchars($property['description'])); ?></p>
                                <p><strong>السعر:</strong> <?php echo number_format($property['price']); ?> ريال</p>
                                <p><strong>المالك:</strong> <?php echo htmlspecialchars($property['full_name']); ?></p>
                                <button class="request-btn" onclick="requestProperty('<?php echo htmlspecialchars(addslashes($property['title'])); ?>', '<?php echo htmlspecialchars($property['contact_phone']); ?>')">
                                    إظهار رقم التواصل
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <script>
        // --- جميع أكواد JavaScript هنا ---

        function toggleMenu() {
            const nav = document.getElementById("navLinks");
            const menuIcon = document.getElementById("menuIcon");
            const closeIcon = document.getElementById("closeIcon");
            const overlay = document.getElementById("overlay");
            const isActive = nav.classList.toggle("active");
            
            menuIcon.style.display = isActive ? 'none' : 'block';
            closeIcon.style.display = isActive ? 'block' : 'none';
            overlay.classList.toggle("show", isActive);
        }

        function changeSlide(button, direction) {
            const slider = button.closest('.image-slider');
            const images = slider.querySelectorAll('img');
            if (images.length < 2) return;

            let activeIndex = Array.from(images).findIndex(img => img.classList.contains('active'));
            
            images[activeIndex].classList.remove('active');
            let newIndex = (activeIndex + direction + images.length) % images.length;
            images[newIndex].classList.add('active');
        }

        function requestProperty(title, phone) {
            alert(
                `للتواصل بخصوص العقار:\n"${title}"\n\n` +
                `يمكنك الاتصال بالمالك مباشرة على الرقم:\n${phone}\n\n` +
                `ملاحظة: المنصة هي للعرض فقط وغير مسؤولة عن الاتفاقيات.`
            );
        }
    </script>
</body>
</html>